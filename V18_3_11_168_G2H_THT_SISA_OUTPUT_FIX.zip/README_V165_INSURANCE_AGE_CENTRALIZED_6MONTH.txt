SCORE V18.3.11.165 - INSURANCE AGE CENTRALIZED 6 MONTH

Basis: V164.

Perubahan:
- Konsolidasi seluruh jalur usia asuransi ke aturan yang sama: naik 1 tahun hanya bila telah mencapai >= 6 bulan sejak ulang tahun terakhir.
- Fungsi berbasis tanggal tetap menghitung sampai tanggal/hari, sehingga ambang tepat pada tanggal ulang tahun + 6 bulan.
- Fallback numerik tidak lagi memakai Math.ceil(); sekarang memakai threshold pecahan usia >= 0,5.
- Jalur simulasi manual/interaktif, verified offer, dan bundling memakai aturan yang sama.
- Service worker dibump ke v165.

Tidak mengubah tarif asuransi, rumus biaya lain, login, Smart Sync, header, bottom menu, maupun Unit Booking.
