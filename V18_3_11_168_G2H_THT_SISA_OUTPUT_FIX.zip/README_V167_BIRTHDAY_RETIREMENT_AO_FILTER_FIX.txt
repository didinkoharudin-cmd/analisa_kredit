SCORE V18.3.11.167 — Birthday/Retirement Card Stability + AO Filter

Basis: V166_DEBTOR_FLAG_SORT.

Perubahan:
1. Perbaikan bug menu Debitur Ulang Tahun / 3 Bulan Menuju Pensiun:
   - pilihan kartu tidak lagi bergantung pada identitas object JavaScript yang dapat berubah saat Smart Sync/background refresh.
   - saat tombol Buka WhatsApp ditekan, debitur di-resolve ulang menggunakan CIF stabil pada database cabang aktif.
   - sehingga menunggu beberapa saat setelah memilih kartu tidak lagi memunculkan pesan "Data/sesi berubah" hanya karena data direfresh di background.
   - proteksi sesi tetap dipertahankan: bila CIF benar-benar sudah tidak ada/akses berubah, alert tetap muncul.

2. Filter AO khusus user pengelola:
   - ADMIN, SPV, SUPERVISOR, SUPER_ADMIN melihat dropdown "Filter AO".
   - pilihan: Semua AO + kode AO yang mempunyai debitur sesuai menu (ulang tahun / menuju pensiun).
   - AO biasa tidak melihat dropdown dan tetap hanya melihat data miliknya sendiri.
   - filter AO dapat dipakai bersama pencarian nama/CIF/AO/instansi.

3. Tidak mengubah perhitungan kredit, insurance age V165, debtor flag sort V166, login, Smart Sync, header, bottom menu, atau backend.
4. Service Worker cache dinaikkan ke V167.
