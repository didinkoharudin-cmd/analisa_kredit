SCORE V142 — Navigasi Home lebih bawah pada iPhone

Navigasi Home sekarang memanjang ke area indikator Home iPhone, dan posisi ikon diturunkan sedikit. Warna tema dan dasar PWA dibuat putih agar area sistem di bawah aplikasi menyatu dengan navigasi.

Deploy seluruh isi folder frontend ke akar situs. Tutup penuh lalu buka kembali dari ikon aplikasi. Perbaikan Admin V140 dan Back Android tetap disertakan. Tidak ada perubahan Apps Script.

Validasi: struktur aset cache, syntax service worker, integritas ZIP. Belum diuji langsung pada iPhone fisik.
