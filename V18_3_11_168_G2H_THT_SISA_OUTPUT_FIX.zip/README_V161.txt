SCORE V18.3.11.161 — STARTUP PERFORMANCE SAFE
==============================================
Base: V18_3_11_160_AO_BRANCH_UNIT_BOOKING_FIX

TUJUAN
------
Mengurangi request bersamaan tepat setelah login dan saat Smart Sync tanpa
mengubah UI V160, tanpa membuang request, dan tanpa menjadikan kegagalan modul
latar belakang sebagai kegagalan login.

PERUBAHAN FRONTEND
------------------
1. Startup Network Coordinator
   - Setelah login valid, hanya sinkronisasi parameter pusat yang diprioritaskan.
   - Request otomatis seperti banner, klasemen, monthly flag, traffic, unread
     chat, dokumen, funnel, pipeline, dan dashboard tambahan ditahan sementara.
   - Selama Smart Sync aktif, request background tetap menunggu; tidak dibatalkan.
   - Timer timeout HTTP baru dimulai setelah request benar-benar mendapat giliran,
     sehingga waktu tunggu antrean tidak dihitung sebagai timeout jaringan.

2. Single-flight / coalescing request
   - Request GET identik yang dipanggil beberapa timer pada saat bersamaan memakai
     satu Promise/request yang sama.
   - Kunci request menyertakan identitas sesi credential sehingga tidak bercampur
     antar sesi login.
   - getParameters, getDataVersion, dan getData juga dilindungi dari duplikasi
     request identik saat masih in-flight.

3. Smart Sync single-flight
   - Hanya satu loadProtectedData / Smart Sync yang boleh berjalan pada satu waktu.
   - Klik ganda atau pemanggil kedua menunggu Promise yang sama, bukan membuat
     getDataVersion/getData paralel.
   - Smart Sync menunggu bootstrap parameter pusat maksimal 7,5 detik. Jika server
     parameter sedang lambat, proses database tetap dilanjutkan dengan mekanisme
     fallback parameter lokal yang sudah ada.

4. Bootstrap login disederhanakan
   - Request berulang banner/klasemen/heartbeat dari bootstrap login dihapus.
   - Modul-modul tersebut tetap memiliki bootstrap/retry masing-masing dan kini
     dikoordinasikan melalui antrean startup.
   - Monthly Offer Flag memiliki satu fail-safe terjadwal karena timer awalnya
     dapat terjadi sebelum credential tersedia.
   - Restore session menggunakan jalur bootstrap yang sama dengan login baru.

5. Banner menggunakan callApi utama
   - Request banner sekarang ikut proteksi sesi, coalescing, timeout, dan antrean
     startup yang sama dengan API lain.
   - Direct fetch lama tetap tersedia sebagai fallback bila callApi belum siap.

PERBAIKAN SERVICE WORKER
------------------------
1. Cache baru: V18.3.11.161-startup-performance-safe.
2. Precache tidak lagi mengunduh './' dan './index.html' sekaligus.
3. icon-192/icon-512 duplikat tidak diprecache; score-icon digunakan sebagai aset
   utama. File lama tetap dipertahankan agar kompatibel dengan referensi lama.
4. Estimasi payload precache turun dari ±3,43 MB menjadi ±1,97 MB (±42,6% lebih
   ringan berdasarkan file paket ini).
5. Gagal mengunduh satu aset opsional tidak lagi menggagalkan instalasi seluruh
   service worker; setiap aset dicache secara independen.
6. Navigasi memakai fast-network + cached fallback: jaringan diberi kesempatan
   sekitar 700 ms; bila lambat, halaman cache dibuka segera sementara versi online
   tetap diperbarui.
7. Registrasi/update service worker ditunda sampai startup/Smart Sync tidak sedang
   berada pada fase kritis, agar precache tidak berebut bandwidth saat login.
8. Push notification tetap dipertahankan dan menggunakan score-icon-192.

YANG TIDAK DIUBAH
-----------------
- Tampilan header dan bottom menu V160.
- Safe area iPhone/PWA.
- AO Unit Booking lintas unit dalam cabang V160.
- Backend / Google Apps Script / Cloudflare Worker.
- Rumus kredit, Smart Sync cache schema, filter cabang, role, dan hak akses.

DEPLOY
------
Deploy folder frontend seperti V160. Tidak diperlukan perubahan Apps Script atau
Cloudflare Worker untuk V161.

PENGUJIAN YANG DISARANKAN
-------------------------
1. Tutup PWA sepenuhnya lalu buka kembali.
2. Login Google dan pastikan Menu/Pilih Sumber Database muncul tanpa kembali ke
   layar login.
3. Segera tekan Database Google Script / Smart Sync.
4. Pastikan proses versi/cache/getData selesai dan aplikasi terbuka.
5. Setelah Smart Sync selesai, periksa banner, klasemen, flag penawaran, chat,
   dokumen, dan traffic; semuanya harus tetap termuat secara bertahap.
6. Ulangi Smart Sync dua kali cepat; request database kedua seharusnya tidak
   berjalan paralel.
