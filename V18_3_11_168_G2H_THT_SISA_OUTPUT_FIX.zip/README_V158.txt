V158 — Seamless iPhone PWA bottom surface

Perubahan hanya pada warna permukaan bawah, tanpa mengubah ukuran/posisi bottom menu:
- Bottom menu memakai warna dasar header SCORE yang sama: #238ebc.
- Safe-area / area di bawah bottom menu pada iPhone PWA memakai warna yang sama persis.
- Pseudo-element safe-bottom V156 dioverride menjadi warna yang sama, sehingga tidak ada transisi/garis potong gelap.
- Background artwork header tetap dipertahankan di bagian atas.
- Login Google, halaman Admin, modal/full-screen, Safari browser, Android, dan desktop tidak diubah oleh patch ini.
- Service worker dinaikkan ke cache V158 agar CSS terbaru langsung terambil setelah deploy/reload.
