SCORE V18.3.11.166 - DEBTOR FLAG SORT

Basis: V165.

Perubahan:
- Pada halaman/rincian daftar kartu Debitur ditambahkan dropdown URUTAN (bukan filter).
- Opsi 1: Belum terflag -> Sudah terflag.
- Opsi 2: Sudah terflag -> Belum terflag.
- Di dalam kelompok yang sudah terflag, kartu diurutkan berdasarkan tanggal flag paling lama dahulu.
- Kelompok yang belum terflag mempertahankan urutan hasil filter/potensi yang sudah ada.
- Mengganti urutan tidak menyembunyikan kartu apa pun; hanya mengubah posisi kartu dan reset pagination ke awal.
- Default tetap Belum terflag -> Sudah terflag agar perilaku V165 tidak berubah sampai pengguna memilih opsi lain.
- Service worker dibump ke v166.

Tidak mengubah perhitungan kredit/asuransi, login, Smart Sync, header, bottom menu, Unit Booking, flag persistence, ataupun backend.
