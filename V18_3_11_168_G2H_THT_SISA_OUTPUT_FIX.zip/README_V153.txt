SCORE V153 — Bottom Nav Blue + iPhone Safe-Top Targeted Fix

Basis: V152 / layout stabil V142.

Perubahan yang sengaja dibatasi:
1. Bottom menu mobile: hanya warna permukaan yang diubah dari putih menjadi biru #238ebc, yaitu warna dasar header SCORE. Posisi, tinggi, radius, tombol, ikon, dan tombol WhatsApp tidak diubah.
2. iPhone — Debitur berulang tahun: header/kontrol diturunkan agar tidak masuk area status bar.
3. iPhone — Debitur 3 bulan menuju pensiun: perbaikan safe-top yang sama.
4. iPhone — Tabel Angsuran Produk: kartu modal dimulai di bawah area status bar; isi dan desain tidak diubah.
5. iPhone — Persyaratan Produk: memakai perbaikan safe-top yang sama dengan Tabel Angsuran.
6. Android dan desktop tidak diberi perubahan layout baru.
7. Stylesheet dinaikkan menjadi score-v153.css dan cache Service Worker dinaikkan ke V153 agar warna baru tidak tertahan cache V152.

Deploy seluruh isi folder frontend. Setelah deploy, tutup penuh PWA lalu buka kembali agar Service Worker V153 mengambil stylesheet baru.
