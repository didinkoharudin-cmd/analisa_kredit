SCORE V18.3.11.164 - INSURANCE AGE 6 MONTH ROUNDING

Base: V18.3.11.163 JSON Response Recovery.

Perubahan:
- Aturan usia asuransi diubah.
- Pembulatan ke tahun berikutnya hanya berlaku jika sisa usia setelah ulang tahun terakhir sudah >= 6 bulan.
- Contoh:
  * 39 tahun 0-5 bulan => usia asuransi 39
  * 39 tahun 6-11 bulan => usia asuransi 40
  * tepat 40 tahun => usia asuransi 40
- Berlaku pada kartu potensi, simulasi interaktif/manual, penawaran WA, dan perhitungan biaya yang memakai usia asuransi terpusat.
- Fallback usia numerik juga menggunakan ambang 0,5 tahun, bukan Math.ceil.
- Tidak ada perubahan UI, login, Smart Sync, bottom nav, header, Unit Booking, atau parameter biaya lainnya.
- Service worker dibump ke v164 agar aturan baru tidak tertahan cache lama.
