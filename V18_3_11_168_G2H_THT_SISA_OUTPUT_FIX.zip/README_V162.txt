V18.3.11.162 — LOGIN & SMART SYNC PRIORITY
==========================================

Fokus perbaikan berdasarkan pengujian V161 pada jaringan 4G/iPhone:

1. SMART SYNC LANGSUNG MERESPON
- V161 menunggu parameter pusat sampai 7,5 detik sebelum fungsi Smart Sync asli dijalankan.
- V162 menghapus wait tersebut.
- Saat tombol Smart Sync ditekan, guard/progress langsung muncul dan getDataVersion langsung diprioritaskan.
- Klik ganda tetap memakai satu proses yang sama (single-flight), sehingga tidak membuat request ganda.

2. PARAMETER TIDAK BEREBUT JARINGAN DENGAN SMART SYNC
- Parameter pusat tidak lagi ditembak tepat setelah login.
- Dijadwalkan setelah login dan otomatis ditunda bila Smart Sync sedang berjalan.
- Setelah Smart Sync selesai, sinkronisasi parameter tetap dijalankan agar fungsi tidak hilang.
- Cache parameter lokal tetap menjadi fallback seperti sebelumnya.

3. SERVICE WORKER TIDAK BOLEH MENGGANGGU LOGIN
- Pada V161, registrasi SW dapat mulai beberapa detik setelah halaman load walaupun user masih di layar login.
- V162 menahan registrasi/update SW selama app masih terkunci/login, selama Smart Sync, dan minimal 10 detik setelah autentikasi sukses.
- Precache diubah dari banyak download paralel menjadi sequential untuk menghindari saturasi 4G.
- Navigasi PWA dengan cache tersedia memakai batas tunggu jaringan 450ms agar shell cepat tampil.

4. KEAMANAN REQUEST
- Request login tetap menunggu jawaban backend valid sebelum sesi dianggap berhasil.
- Retry login tidak dihapus.
- Request background tidak dibuang; hanya ditunda/diantrekan.
- getData tetap tidak diretry otomatis agar tidak membuat dua proses database besar bersamaan.

5. TIDAK DIUBAH
- UI/header/bottom menu/safe area V160.
- Input realisasi AO + unit booking lintas unit satu cabang.
- Perhitungan kredit, parameter, role, multi-branch, banner, chat, pipeline, dan modul lainnya.
