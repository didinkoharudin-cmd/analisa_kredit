SCORE V18.3.11.168 — G2H-THT Output / WhatsApp Fix

Perbaikan:
- Hasil download/gambar simulasi G2H-THT sekarang memakai Sisa THT = Perkiraan THT - Plafond Gross.
- Perkiraan THT diambil dari input khusus G2H (v18SpecialIncome), bukan input penghasilan reguler yang menyebabkan hasil 0.
- Pesan WhatsApp simulasi G2H-THT sekarang menampilkan Perkiraan THT, Total Bunga, dan Sisa THT.
- Produk selain G2H-THT tidak diubah.
- Seluruh perubahan V167 tetap dipertahankan.
