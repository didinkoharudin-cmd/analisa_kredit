V160 — AO Branch Unit Booking Fix

Perbaikan dari V159:
- Memperbaiki kasus pada akun AO di mana dropdown Unit Booking hanya berisi kantor penempatan AO sendiri (contoh: CABANG).
- AO sekarang mengambil daftar unit dari data Klasemen Home AO yang sudah dibatasi oleh cabang login, lalu menggabungkannya dengan officeOptions dari endpoint monitoring.
- Kantor penempatan AO tetap menjadi pilihan awal/default, tetapi AO dapat memilih kantor AO lain yang masih berada dalam cabang yang sama.
- Tidak membuka akses unit lintas cabang: sumber daftar tambahan tetap berasal dari endpoint AO yang branch-scoped.
- Jika endpoint klasemen sementara gagal, form tetap berfungsi memakai officeOptions server / kantor AO sendiri sebagai fallback.
- Admin/SPV tidak diubah.
- Tampilan, safe-area, bottom menu, header SCORE, Android/Desktop, dan patch V158/V159 tetap dipertahankan.
- Cache service worker dinaikkan ke V160.
