V18.3.11.163 — JSON RESPONSE RECOVERY

Fokus perbaikan:
- Menangani kasus sporadis "Respons server bukan JSON" tanpa memutus sesi login.
- Respons kosong, HTML gateway/Cloudflare, status 408/425/429/5xx, dan gangguan jaringan diklasifikasikan sebagai gangguan sementara.
- Login, getDataVersion, dan request read-only yang sudah memiliki retry akan mencoba ulang secara berurutan, bukan paralel.
- getData mendapat maksimum satu retry berurutan hanya untuk respons gateway/non-JSON atau koneksi terputus; timeout panjang tidak diulang agar tidak membuat proses database ganda.
- UTF-8 BOM dan prefix anti-XSSI dibersihkan sebelum JSON.parse.
- Jika gangguan tetap terjadi setelah retry, pesan user menjadi lebih aman: sesi tetap aktif dan user cukup mencoba kembali.
- Tidak mengubah struktur data, perhitungan kredit, role, tampilan, bottom menu, header, atau Smart Sync V162.
- Service worker cache dinaikkan ke V163 agar patch langsung terambil setelah deploy.
