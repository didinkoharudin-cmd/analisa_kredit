V155 micro patch: fill the exposed iPhone safe-bottom strip below the mobile bottom nav with the same blue gradient as the nav, while keeping the safe-area room and previous V154 geometry.
