V159 — AO Self Realization + Unit Booking

Perubahan utama:
- Input realisasi kredit tidak hanya tersedia untuk Admin/Supervisor; AO masuk ke form realisasi miliknya sendiri dari menu Laporan Harian & Realisasi.
- Data form AO dikirim tanpa pilihan AO tujuan sehingga tetap terikat ke akun AO yang sedang login.
- Unit Booking pada form AO wajib dipilih dan dapat dipilih dari daftar unit yang tersedia di cabang aktif.
- Kantor penempatan AO hanya dipakai sebagai pilihan awal/default; AO tetap bebas memilih unit booking lain dalam cabang aktif.
- Ditambahkan validasi agar unit booking kosong / di luar daftar unit aktif tidak tersimpan.
- Riwayat, edit, dan hapus pada tampilan AO tetap hanya untuk data realisasi AO tersebut.
- Form Admin/Supervisor untuk menginput realisasi AO lain tetap dipertahankan tanpa perubahan alur.
- Safe-area, bottom menu, header SCORE, halaman Admin, Android/Desktop, dan patch visual V158 tidak diubah.
- Cache service worker dinaikkan ke V159.
